#!/bin/bash
PATH=/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin
python /root/Documents/4chan-b/4chan-b-scraper.py
sleep 1m
python /root/Documents/4chan-b/corpusmaker.py
